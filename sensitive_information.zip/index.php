<?php
$PATH_TWO="and_wwwzip_is_0posec}"
echo "<h1>网站管理员泄露一些敏感文件看看你能不能从敏感文件中找到flag</h1>"
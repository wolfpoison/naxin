<?php
error_reporting(0);
highlight_file(__FILE__);
require_once('classes.php');

if (isset($_FILES['file'])) {
    $upload_dir = '/var/www/html/uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir);
    }
    
    $target_file = $upload_dir . basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        echo "File uploaded successfully!<br>";
        
        try {
            $phar = new Phar($target_file);
            $metadata = $phar->getMetadata();
            echo "File metadata analyzed.<br>";
        } catch (Exception $e) {
            echo "Error reading file metadata";
        }
    } else {
        echo "File upload failed";
    }
}
?>
<hr>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="file">
    <input type="submit" value="Upload">
</form>

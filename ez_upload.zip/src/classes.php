<?php
class FileProcessor {
    private $handler;
    
    public function __destruct() {
        $this->handler->cleanup();
    }
}

class TempFileHandler {
    public $filename;
    
    public function cleanup() {
        // 触发__toString的关键点
        echo "Cleaning: " . $this->filename . "<br>";
        if (file_exists((string)$this->filename)) {
            unlink((string)$this->filename);
        }
    }
}

class Logger {
    private $log_content;
    
    public function __toString() {
        $flag = getenv('FLAG');
        return base64_encode($flag);
    }
}

class DatabaseConnection {
    // 保留混淆类
    public $query;
    
    public function execute() {
        new PDO('sqlite::memory:');
        return "Executed: ".$this->query;
    }
}
